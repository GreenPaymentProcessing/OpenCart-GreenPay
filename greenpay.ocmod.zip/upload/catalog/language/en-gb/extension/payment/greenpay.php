<?php
// Text
$_['text_redirect'] = 'You will be redirected to payment page in a few seconds';
$_['text_card'] = 'GreenPay™ eCheck';

// Error
$_['error_card_type'] = 'Both Account number and Routing Number are required';
$_['error_order_not_found'] = 'Order not found';
$_['error_something_wrong'] = 'Something went wrong';
$_['error_get'] = 'Missing GET parameters';
$_['error_action'] = 'Unknown action';
$_['error_param'] = 'Missing parameters';
